# Frontend Masters: CSS Grids and Flexbox in Responsive Web Design workshop files

Taught October 3-4, 2017, at Frontend Masters

Course is located here: https://frontendmasters.com/courses/css-grids-flexbox/ 
